﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ControlGastos.Data.Migrations
{
    /// <inheritdoc />
    public partial class UpdateFondoMonetarioModel : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "UsuarioId",
                table: "FondosMonetarios",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.CreateIndex(
                name: "IX_FondosMonetarios_UsuarioId",
                table: "FondosMonetarios",
                column: "UsuarioId");

            migrationBuilder.AddForeignKey(
                name: "FK_FondosMonetarios_AspNetUsers_UsuarioId",
                table: "FondosMonetarios",
                column: "UsuarioId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FondosMonetarios_AspNetUsers_UsuarioId",
                table: "FondosMonetarios");

            migrationBuilder.DropIndex(
                name: "IX_FondosMonetarios_UsuarioId",
                table: "FondosMonetarios");

            migrationBuilder.AlterColumn<string>(
                name: "UsuarioId",
                table: "FondosMonetarios",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");
        }
    }
}
