﻿using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace ControlGastos.Models
{
    public class FondoMonetario
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }

        [BindNever]
        public string UsuarioId { get; set; } // Foreign key to ApplicationUser
    }
}