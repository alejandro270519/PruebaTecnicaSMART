﻿namespace ControlGastos.Models
{
    public class TipoGasto
    {
        public int Id { get; set; }
        public string? Codigo { get; set; }
        public string Nombre { get; set; }
    }
}