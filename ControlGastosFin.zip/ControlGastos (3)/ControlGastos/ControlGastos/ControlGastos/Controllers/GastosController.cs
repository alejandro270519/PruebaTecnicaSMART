﻿using ControlGastos.Data;
using ControlGastos.Models;
using ControlGastos.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace ControlGastos.Controllers
{
    [Authorize]
    public class GastosController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public GastosController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public IActionResult Create()
        {
            ViewBag.Fondos = _context.FondosMonetarios.ToList();
            ViewBag.TiposGasto = _context.TiposGasto.ToList();
            return View(new GastoRegistroViewModel
            {
                Detalles = new List<GastoDetalle> { new GastoDetalle() }
            });
        }

        [HttpPost]
        public async Task<IActionResult> Create(GastoRegistroViewModel vm)
        {
            var userId = _userManager.GetUserId(User);
            using var transaction = await _context.Database.BeginTransactionAsync();

            try
            {
                vm.Encabezado.UsuarioId = userId;
                _context.GastosEncabezado.Add(vm.Encabezado);
                await _context.SaveChangesAsync();

                foreach (var detalle in vm.Detalles)
                {
                    detalle.EncabezadoId = vm.Encabezado.Id;
                    _context.GastosDetalle.Add(detalle);
                }

                await _context.SaveChangesAsync();

                // Validar si sobrepasa presupuesto
                var sobregiros = vm.Detalles
                    .GroupBy(d => d.TipoGastoId)
                    .Select(grupo =>
                    {
                        var tipo = grupo.Key;
                        var sumaDetalle = grupo.Sum(x => x.Monto);

                        var presupuesto = _context.Presupuestos.FirstOrDefault(p =>
                            p.UsuarioId == userId &&
                            p.TipoGastoId == tipo &&
                            p.Mes == vm.Encabezado.Fecha.Month &&
                            p.Anio == vm.Encabezado.Fecha.Year
                        );

                        var ejecutado = _context.GastosDetalle
                            .Include(g => g.Encabezado)
                            .Where(g => g.TipoGastoId == tipo &&
                                        g.Encabezado.UsuarioId == userId &&
                                        g.Encabezado.Fecha.Month == vm.Encabezado.Fecha.Month &&
                                        g.Encabezado.Fecha.Year == vm.Encabezado.Fecha.Year)
                            .Sum(g => g.Monto);

                        if (presupuesto != null && ejecutado + sumaDetalle > presupuesto.Monto)
                        {
                            return new
                            {
                                Tipo = tipo,
                                MontoPresupuestado = presupuesto.Monto,
                                MontoActual = ejecutado + sumaDetalle
                            };
                        }

                        return null;
                    })
                    .Where(x => x != null)
                    .ToList();

                await transaction.CommitAsync();

                if (sobregiros.Any())
                {
                    TempData["Alerta"] = string.Join("<br/>", sobregiros.Select(s =>
                        $"⚠ Presupuesto sobregirado en tipo de gasto ID: {s.Tipo}. Presupuesto: {s.MontoPresupuestado:C}, Actual: {s.MontoActual:C}"
                    ));
                }

                return RedirectToAction("Create");
            }
            catch
            {
                await transaction.RollbackAsync();
                ModelState.AddModelError("", "Error al guardar los datos.");
                return View(vm);
            }
        }
    }
}
