﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using ControlGastos.Data;
using ControlGastos.Models;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ControlGastos.Controllers
{
    [Authorize]
    public class PresupuestosController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public PresupuestosController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public IActionResult Index()
        {
            var userId = _userManager.GetUserId(User);
            var presupuestos = _context.Presupuestos
                .Include(p => p.TipoGasto)
                .Where(p => p.UsuarioId == userId)
                .ToList();

            return View(presupuestos);
        }

        public IActionResult Create()
        {
            ViewBag.TiposGasto = _context.TiposGasto
                .Select(g => new SelectListItem
                {
                    Value = g.Id.ToString(),
                    Text = g.Nombre
                }).ToList();

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Presupuesto p)
        {
            if (ModelState.IsValid)
            {
                p.UsuarioId = _userManager.GetUserId(User);
                _context.Add(p);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            // Reasignar el ViewBag si el modelo no es válido y se vuelve a la vista
            ViewBag.TiposGasto = _context.TiposGasto
                .Select(g => new SelectListItem
                {
                    Value = g.Id.ToString(),
                    Text = g.Nombre
                }).ToList();

            return View(p);
        }

    }
}