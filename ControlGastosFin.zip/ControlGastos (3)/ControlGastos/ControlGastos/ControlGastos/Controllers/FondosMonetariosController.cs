﻿using Microsoft.AspNetCore.Mvc;
using ControlGastos.Data;
using ControlGastos.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Authorization;
using System.Threading.Tasks;
using System.Linq;
using System.Security.Claims;

namespace ControlGastos.Controllers
{
    [Authorize]
    public class FondosMonetariosController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public FondosMonetariosController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public IActionResult Index()
        {
            var userId = _userManager.GetUserId(User);
            var fondos = _context.FondosMonetarios.Where(f => f.UsuarioId == userId).ToList();
            return View(fondos);
        }

        public IActionResult Create() => View();

        [HttpPost]
        public async Task<IActionResult> Create(FondoMonetario fondo)
        {
            fondo.UsuarioId = User.FindFirstValue(ClaimTypes.NameIdentifier); // Asigna el UsuarioId

            ModelState.Remove(nameof(fondo.UsuarioId)); // Evita error de validación por UsuarioId

            if (!ModelState.IsValid)
            {
                foreach (var error in ModelState.Values.SelectMany(v => v.Errors))
                {
                    Console.WriteLine(error.ErrorMessage);
                }

                return View(fondo); // Devuelve la vista con errores
            }

            _context.Add(fondo);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "¡Fondo agregado correctamente!";
            return RedirectToAction(nameof(Index));
        }


    }
}
