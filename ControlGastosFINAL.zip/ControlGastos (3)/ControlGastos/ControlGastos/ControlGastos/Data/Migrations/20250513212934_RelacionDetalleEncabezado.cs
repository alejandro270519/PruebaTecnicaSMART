﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ControlGastos.Data.Migrations
{
    /// <inheritdoc />
    public partial class RelacionDetalleEncabezado : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Presupuestos_TipoGastoId",
                table: "Presupuestos",
                column: "TipoGastoId");

            migrationBuilder.CreateIndex(
                name: "IX_GastosDetalle_EncabezadoId",
                table: "GastosDetalle",
                column: "EncabezadoId");

            migrationBuilder.AddForeignKey(
                name: "FK_GastosDetalle_GastosEncabezado_EncabezadoId",
                table: "GastosDetalle",
                column: "EncabezadoId",
                principalTable: "GastosEncabezado",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Presupuestos_TiposGasto_TipoGastoId",
                table: "Presupuestos",
                column: "TipoGastoId",
                principalTable: "TiposGasto",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_GastosDetalle_GastosEncabezado_EncabezadoId",
                table: "GastosDetalle");

            migrationBuilder.DropForeignKey(
                name: "FK_Presupuestos_TiposGasto_TipoGastoId",
                table: "Presupuestos");

            migrationBuilder.DropIndex(
                name: "IX_Presupuestos_TipoGastoId",
                table: "Presupuestos");

            migrationBuilder.DropIndex(
                name: "IX_GastosDetalle_EncabezadoId",
                table: "GastosDetalle");
        }
    }
}
