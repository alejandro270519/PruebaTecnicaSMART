﻿using ControlGastos.Models;
using System.Collections.Generic;

namespace ControlGastos.ViewModels
{
    public class GastoRegistroViewModel
    {
        public GastoEncabezado Encabezado { get; set; }
        public List<GastoDetalle> Detalles { get; set; }
    }
}