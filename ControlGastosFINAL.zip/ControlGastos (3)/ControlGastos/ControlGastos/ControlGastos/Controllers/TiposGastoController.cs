﻿using Microsoft.AspNetCore.Mvc;
using ControlGastos.Data;
using ControlGastos.Models;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using static System.Net.Mime.MediaTypeNames;

namespace ControlGastos.Controllers
{
    [Authorize]
    public class TiposGastoController : Controller
    {
        private readonly ApplicationDbContext _context;

        public TiposGastoController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: TiposGasto
        public IActionResult Index()
        {
            return View(_context.TiposGasto.ToList());
        }

        // GET: TiposGasto/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: TiposGasto/Create
        [HttpPost]
        public async Task<IActionResult> Create(TipoGasto tipoGasto)
        {
            if (ModelState.IsValid)
            {
                // Generar código automático (ej: TG001)
                int total = _context.TiposGasto.Count() + 1;
                tipoGasto.Codigo = $"TG{total.ToString("D3")}";

                _context.Add(tipoGasto);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(tipoGasto);
        }

        // GET: TiposGasto/Edit/5
        public IActionResult Edit(int id)
        {
            var tipo = _context.TiposGasto.Find(id);
            if (tipo == null) return NotFound();
            return View(tipo);
        }

        // POST: TiposGasto/Edit
        [HttpPost]
        public async Task<IActionResult> Edit(TipoGasto tipoGasto)
        {
            ModelState.Remove(nameof(tipoGasto.Codigo)); // Evita error de validación por UsuarioId

            if (ModelState.IsValid)
            {
                _context.Update(tipoGasto);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(tipoGasto);
        }

        // GET: TiposGasto/Delete/5
        public IActionResult Delete(int id)
        {
            var tipo = _context.TiposGasto.Find(id);
            if (tipo == null) return NotFound();
            return View(tipo);
        }

        // POST: Confirm Delete
        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var tipo = _context.TiposGasto.Find(id);
            _context.TiposGasto.Remove(tipo);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}
