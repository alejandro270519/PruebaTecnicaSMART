﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using ControlGastos.Data;
using ControlGastos.Models;
using System.Linq;
using System.Threading.Tasks;

namespace ControlGastos.Controllers
{
    [Authorize]
    public class DepositosController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public DepositosController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public IActionResult Create()
        {
            ViewBag.Fondos = _context.FondosMonetarios.ToList();
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Depositos d)
        {
            if (ModelState.IsValid)
            {
                d.UsuarioId = _userManager.GetUserId(User);
                _context.Depositos.Add(d);
                await _context.SaveChangesAsync();
                return RedirectToAction("Create");
            }

            ViewBag.Fondos = _context.FondosMonetarios.ToList();
            return View(d);
        }
    }
}
