﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ControlGastos.Data;
using System;
using System.Linq;

namespace ControlGastos.Controllers
{
    [Authorize]
    public class ConsultasController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ConsultasController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Movimientos(DateTime? desde, DateTime? hasta)
        {
            ViewBag.Desde = desde?.ToString("yyyy-MM-dd");
            ViewBag.Hasta = hasta?.ToString("yyyy-MM-dd");

            if (desde == null || hasta == null)
                return View(null);

            var gastos = _context.GastosEncabezado
                .Where(g => g.Fecha >= desde && g.Fecha <= hasta)
                .ToList();

            var depositos = _context.Depositos
                .Where(d => d.Fecha >= desde && d.Fecha <= hasta)
                .ToList();

            ViewBag.Depositos = depositos;
            return View(gastos);
        }
        public IActionResult GraficoComparativo(DateTime? desde, DateTime? hasta)
        {
            ViewBag.Desde = desde?.ToString("yyyy-MM-dd");
            ViewBag.Hasta = hasta?.ToString("yyyy-MM-dd");

            if (desde == null || hasta == null)
                return View(null);

            var userId = User.Identity.Name;

            var presupuestos = _context.Presupuestos.ToList();
            var gastos = _context.GastosDetalle
                .Where(d => d.Encabezado.Fecha >= desde && d.Encabezado.Fecha <= hasta)
                .ToList();

            var datos = presupuestos
                .GroupBy(p => p.TipoGastoId)
                .Select(grupo => new
                {
                    Tipo = grupo.Key,
                    Presupuestado = grupo.Sum(x => x.Monto),
                    Ejecutado = gastos.Where(g => g.TipoGastoId == grupo.Key).Sum(g => g.Monto)
                }).ToList();

            ViewBag.Etiquetas = string.Join(",", datos.Select(d => $"\"TG-{d.Tipo}\""));
            ViewBag.Presupuesto = string.Join(",", datos.Select(d => d.Presupuestado));
            ViewBag.Ejecucion = string.Join(",", datos.Select(d => d.Ejecutado));

            return View();
        }

    }
}
