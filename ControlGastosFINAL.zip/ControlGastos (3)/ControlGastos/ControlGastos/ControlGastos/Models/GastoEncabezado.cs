﻿using System;

namespace ControlGastos.Models
{
    public class GastoEncabezado
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public int FondoMonetarioId { get; set; }
        public string UsuarioId { get; set; }
        public string Observaciones { get; set; }
        public string NombreComercio { get; set; }
        public string TipoDocumento { get; set; }
    }
}