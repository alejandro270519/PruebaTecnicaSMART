﻿using System;

namespace ControlGastos.Models
{
    public class Depositos
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public int FondoMonetarioId { get; set; }
        public decimal Monto { get; set; }
        public string? UsuarioId { get; set; }
    }
}