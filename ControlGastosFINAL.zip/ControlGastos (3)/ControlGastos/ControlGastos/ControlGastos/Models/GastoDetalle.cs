﻿namespace ControlGastos.Models
{
    public class GastoDetalle
    {
        public int Id { get; set; }
        public int EncabezadoId { get; set; }
        public int TipoGastoId { get; set; }
        public decimal Monto { get; set; }


        public GastoEncabezado Encabezado { get; set; }
    }
}