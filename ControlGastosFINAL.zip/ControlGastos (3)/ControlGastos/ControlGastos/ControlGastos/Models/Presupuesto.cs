﻿namespace ControlGastos.Models
{
    public class Presupuesto
    {
        public int Id { get; set; }
        public string? UsuarioId { get; set; } 
        public int TipoGastoId { get; set; }
        public int Mes { get; set; }
        public int Anio { get; set; }
        public decimal Monto { get; set; }


        public TipoGasto? TipoGasto { get; set; }
    }
}